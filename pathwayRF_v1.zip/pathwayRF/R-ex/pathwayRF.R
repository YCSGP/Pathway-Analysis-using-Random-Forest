### Name: pathwayRF
### Title: Pathway analysis using Random Forests
### Aliases: pathwayRF
### Keywords: pathway

### ** Examples

## load example data
cls_location <- url("http://pantheon.yale.edu/~hhp3/data/canine.cls")
gmt_location <- url("http://pantheon.yale.edu/~hhp3/data/canine.gmt")
gct_location <- url("http://pantheon.yale.edu/~hhp3/data/canine.gct")
## run Random Forests pathway analysis with 5000 trees
## using the canine data
## looking at pathway 1 to 10
PathwayRF(cls_location, gmt_location, gct_location, 5000, 1:10, TRUE)
## save your output in an object called myresults
myresults <- PathwayRF(cls_location, gmt_location, gct_location, 5000, 1:10, TRUE)
## calling myresults
myresults



